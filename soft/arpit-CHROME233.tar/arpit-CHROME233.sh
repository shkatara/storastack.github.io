ssh -X arpit@192.168.0.105 google-chrome --no-sandbox --user-data-dir
