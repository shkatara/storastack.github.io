ssh -X arpit@
 firefox
