ssh -X arpit@192.168.0.6 /bin/bash
