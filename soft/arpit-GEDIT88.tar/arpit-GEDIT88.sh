ssh -X arpit@192.168.122.1 gedit
