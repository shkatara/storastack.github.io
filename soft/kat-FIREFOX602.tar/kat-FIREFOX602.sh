ssh -X kat@192.168.43.196 firefox
