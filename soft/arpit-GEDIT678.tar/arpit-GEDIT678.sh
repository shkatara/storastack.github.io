ssh -X arpit@192.168.0.5 gedit
