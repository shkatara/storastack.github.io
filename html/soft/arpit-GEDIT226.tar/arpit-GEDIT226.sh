ssh -X arpit@192.168.1.106 gedit
