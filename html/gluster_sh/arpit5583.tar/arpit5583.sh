mkdir /media/Sing me to sleep
sudo mount 192.168.1.107:/arpit5583 /media/Sing me to sleep 
