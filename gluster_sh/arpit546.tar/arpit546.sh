mkdir /media/mY storage
sudo mount 192.168.43.193:/arpit546 /media/mY storage
