ssh test@192.168.0.6 scala
